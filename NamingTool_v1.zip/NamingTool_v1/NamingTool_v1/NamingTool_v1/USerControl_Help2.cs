﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamingTool_v1
{
    public partial class USerControl_Help2 : UserControl
    {
        public USerControl_Help2()
        {
            InitializeComponent();
        }

        private void USerControl_Help2_Load(object sender, EventArgs e)
        {

        }
    }
}
