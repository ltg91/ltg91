﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace NamingTool_v1
{
    // 4월 25일 요구사항
    // 파일불러오기 할 시 편집기능 안뜸
    // 선택해서 날짜변경

    //2. 백업안하기 해놓고 두번 누르면 백업 자동으로됨 (사용자 수동 변경)
    //3. 초기화 및 파일명 변경할 경우 
    //4. 도움말 변경
    //5. 자동변경에서 파일올리면 자동으로 파일편집내용 모두 뜨게
    //--완료--
    //1. 똑같은 파일 올리면 (파일불러오기, 파일드래그) 이름 뿐만 아니라... 파일 자체

    //4월6일 요구사항
    
    
    // Image 이쁜것 찾아서
    // 표기법 바꾸기
    // 0, Null이 앞으로
    // 변경안됐으면 빨강색, 변경됐으면 녹색
    // 테스트파일 준비
    // 다음부턴 MVC 패턴 적용
    // 사용자 Regex 사용
    //regex 사용자입력 https://msdn.microsoft.com/ko-kr/library/ms172105(v=vs.80).aspx`
    public partial class Form1 : Form
    {
        List<String> file_List = new List<String>();
        List<String> path_List = new List<String>();    //순수 경로

        List<String> fullName_List = new List<String>();    //전체 파일명(확장자 포함)
        List<String> name_List = new List<String>();    //순수 파일명(확장자 제외)
        List<String> ext_List = new List<String>();     //확장자

        List<String> new_name_List = new List<String>();    //새로운 파일명(순수 파일명 확장자 제외)
        List<String> new_nameIncludingExt_List = new List<String>();    //새로운 파일명(확장자 포함)
        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;
            this.AllowDrop = true;  //드래그를 허용

            //*******Drag관련 이벤트 연결*************
            this.DragOver += new DragEventHandler(Form1_DragOver);
            this.DragDrop += new DragEventHandler(Form1_DragDrop);
        }

        //드래그한 개체가 폼위로 올라갈때
        void Form1_DragOver(object sender, DragEventArgs e)
        {
            //드레그하는 개체가 파일이면
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                //마우스 커서를 Copy모양으로 바꿔준다.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                //아닐경우 커서의 모양을 θ 요런 모양으로 바꾼다.
                e.Effect = DragDropEffects.None;
            }

        }

        //드래그한 개체를 폼위에 올려 놓았을때
        void Form1_DragDrop(object sender, DragEventArgs e)
        {
            
            //객체들의 이름을 string 배열에 얻어온다.
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (null != files)
            {
                foreach (string filename in files)
                {
                    if (file_List.Contains(filename))
                    {
                        MessageBox.Show("중복된 파일을 불러왔습니다.");
                        return;
                    }
                }
            }
            // 드래그한 파일명 Parsing
            if (null != files)
            {
                foreach (string file in files)
                {
                    file_List.Add(file);

                    string path = file.Substring(0, file.LastIndexOf('\\'));
                    path_List.Add(path);

                    string fullName = file.Substring(file.LastIndexOf('\\') + 1);
                    fullName_List.Add(fullName);

                    string name = fullName.Substring(0, fullName.LastIndexOf('.'));
                    name_List.Add(name);

                    string ext = fullName.Substring(fullName.LastIndexOf('.'));
                    ext_List.Add(ext);

                    change_FileName(file);
                }
            }


            AddListBox_ByCase();

            String now = String.Format("{0:MM월d일 HH.mm.ss}", DateTime.Now);
            now = String.Concat("백업파일_", now);
            if (0 == listBox3.Items.Count)
                listBox3.Items.Add(path_List[0] + "\\" + now);

            checkBox1.Visible = true;
        }

        //변환 버튼
        private void button1_Click(object sender, EventArgs e)
        {

            //기존파일 Temp 저장
            String now = listBox3.Items[0].ToString();

            if (System.IO.Directory.Exists(now))
            {
                MessageBox.Show("이미 변경 버튼을 한 번 눌렀습니다. \n초기화 후 다시 진행해주세요.");
                return;
            }

            DirectoryInfo di = new DirectoryInfo(now);
            if (di.Exists == false)
            {
                di.Create();
            }

            if (checkBox3.Checked == true)
            {
                //파일 백업 (백업하기 체크되있으면)
                for (int i = 0; i < file_List.Count; i++)
                {
                    string oldFile = path_List[i] + "\\" + fullName_List[i];
                    string newFile = now + "\\" + fullName_List[i];

                    System.IO.File.Copy(oldFile, newFile);
                }
            }



            //파일명 변경
            for (int i = 0; i < file_List.Count; i++)
            {
                Rename(path_List[i], fullName_List[i], new_nameIncludingExt_List[i]);
            }




            //편집하기 초기화
            Initialization();



            //모든것 클리어
            //path_List.Clear();
            //name_List.Clear();

            //**************************
            //fullName_List.Clear();
            ext_List.Clear();



            MessageBox.Show("변환 성공했습니다.");

        }


        void Initialization()
        {
            //편집하기 초기화
            textBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            checkBox2.Checked = false;
            button4.ForeColor = System.Drawing.Color.Gray;
            button5.ForeColor = System.Drawing.Color.Gray;
            checkBox1.Checked = false;

        }
        int searchNowIndex(String file)
        {
            for (int i = 0; i < file_List.Count; i++)
            {
                if (file_List[i].ToString().Contains(file))
                {
                    //MessageBox.Show(i.ToString());

                    return i;
                }
            }

            return 0;
        }

        void change_FileName(string file)
        {
            string userRegex = textBox3.Text;
            //string 가르기
            //file_List.Add(file);
            int index = searchNowIndex(file);
            string path = file.Substring(0, file.LastIndexOf('\\'));    //순수경로명
            //path_List.Add(path);

            string fullName = file.Substring(file.LastIndexOf('\\') + 1);   //순수파일명
            //fullName_List.Add(fullName);

            string name = fullName.Substring(0, fullName.LastIndexOf('.'));     //확장자제외
            //name_List.Add(name);

            string ext = fullName.Substring(fullName.LastIndexOf('.'));
            //ext_List.Add(ext);

            //C# 정규표현 참조
            //http://cjh7163.blog.me/220448982334

            //문자열 String 참조
            //http://blog.naver.com/zzangna8903/220968881362
            string date = "";
            string version = "v1";    //버전없으면 default v1
            string writer = "";
            //string title="";


            //name 구분자로 나누기
            string[] split_name = name.Split('_', '(', ')', '[', ']');
            name = String.Join(" ", split_name);
            //MessageBox.Show(name);

            //날짜 Parsing
            //날짜형식으로 되어있는 문자열이 파일명에 있으면
            Regex date6Pattern = new Regex(@"[0-1]+[0-9]+[0-1]+[0-9]+[0-3]+[0-9]");
            Regex date8Pattern = new Regex(@"[2]+[0]+[0-1]+[0-9]+[0-1]+[0-9]+[0-3]+[0-9]");

            bool having8Date = date8Pattern.IsMatch(name);
            bool having6Date = date6Pattern.IsMatch(name);

            if (having8Date == true) //8자리 날짜형식으로 된 문자열이 있으면 삭제하고 6자리로 만들고 날짜로 저장
            {
                MatchCollection mc = date8Pattern.Matches(name);
                date = mc[0].ToString();
                name = name.Replace(date, "");

                date = date.Substring(2);

            }

            else if (having6Date == true)
            {
                //6자리로 된거 있으면 6자리로만들고 날짜로 저장
                MatchCollection mc = date6Pattern.Matches(name);
                date = mc[0].ToString();
                name = name.Replace(date, "");

            }
            else
            {
                //없으면 date를 수정한 날짜로
                if (System.IO.File.Exists(file))
                {
                    System.IO.FileInfo fi = new System.IO.FileInfo(file);
                    string YY = fi.LastWriteTime.Year.ToString();

                    YY = YY.Substring(2);
                    if (YY.Length == 1)
                        YY = String.Concat("0", YY);
                    string MM = fi.LastWriteTime.Month.ToString();
                    if (MM.Length == 1)
                        MM = String.Concat("0", MM);
                    string DD = fi.LastWriteTime.Day.ToString();
                    if (DD.Length == 1)
                        DD = String.Concat("0", DD);

                    date = String.Concat(YY, MM, DD);

                }
            }
            //4자리 날짜포맷 지우기
            Regex date4Pattern = new Regex(@"[0-1]+[0-9]+[0-3]+[0-9]");

            bool having4Date = date4Pattern.IsMatch(name);
            if (having4Date == true)
            {
                MatchCollection mc2 = date4Pattern.Matches(name);
                string date4 = mc2[0].ToString();
                name = name.Replace(date4, "");
            }
            name = name.Replace("  ", " ");
            name = name.Trim();
            //MessageBox.Show(name);
            //날짜Parsing 끝

            //버전 Parsing 시작
            name = name.Replace("fin", "vF");
            // Regex versionPattern = new Regex(@"([v|V]+)([0-9]{0,1})([.]{0,1})([f|F]{0,1})");
            //Regex versionPattern = new Regex(@"([v|V]+)([0-9]{1,2}).([0-9]+) | ([v|V]+)([f|F]{1,2}) | ([v|V]+)([0-9]{0,2}) ");
            //Regex versionPattern2 = new Regex(@"([f]+)([i]+)([n]+)");
            //Regex version0Pattern = new Regex(@"([v|V]+([0-9])
            Regex versionPattern = new Regex(@"([v|V]+)([0-9]+).([0-9]+)");  //Regex versionPattern = new Regex(@"([v|V]+)([0-9]+)");
            Regex version1Pattern = new Regex(@"([v|V]+)([0-9]+)");
            Regex version2Pattern = new Regex(@"([v|V]+)([f|F]+)");
            bool havingVersion = versionPattern.IsMatch(name);
            bool havingVersion1 = version1Pattern.IsMatch(name);
            bool havingVersion2 = version2Pattern.IsMatch(name);
            //bool havingVersion2 = versionPattern2.IsMatch(name);
            if (havingVersion == true)  //버전이 있으면 찾아내서 삭제하고 저장
            {
                MatchCollection mc = versionPattern.Matches(name);

                version = mc[0].ToString();
                name = name.Replace(version, "");

            }
            else if (havingVersion1 == true)
            {
                MatchCollection mc = version1Pattern.Matches(name);

                version = mc[0].ToString();
                name = name.Replace(version, "");

            }
            else if (havingVersion2 == true)
            {
                MatchCollection mc = version2Pattern.Matches(name);

                version = mc[0].ToString();
                name = name.Replace(version, "");

            }
            name = name.Replace("  ", " ");
            name = name.Trim();
            //MessageBox.Show(name);
            //버전Parsing 끝

            //작성자 Parsing
            Regex writerPattern = new Regex(@"안건국|조현기|김규태|서대관|이형문|김용진|김수정|이나은|정일균|이준|명용환|정해비치|박상설|이태규");
            Regex writerPattern2 = new Regex(@"안건국GJ|조현기GJ|김규태GJ|서대관GJ|이형문GJ|김용진GJ|김수정DR|이나은DR|정일균DR|이준DR|명용환DR|정해비치SW|박상설SW|이태규SW");
            Regex writerPattern3 = new Regex(@"안건국과장|조현기과장|김규태과장|서대관과장|이형문과장|김용진과장|김수정대리|이나은대리|정일균대리|이준대리|명용환대리|정해비치사원|박상설사원|이태규사원");
            bool havingWriter1 = writerPattern.IsMatch(name);
            bool havingWriter2 = writerPattern2.IsMatch(name);
            bool havingWriter3 = writerPattern3.IsMatch(name);
            if (havingWriter3 == true)
            {
                MatchCollection mc = writerPattern3.Matches(name);
                writer = mc[0].ToString();
                name = name.Replace(writer, "");


            }
            else if (havingWriter2 == true)
            {
                MatchCollection mc = writerPattern2.Matches(name);
                writer = mc[0].ToString();
                name = name.Replace(writer, "");
            }
            else if (havingWriter1 == true)
            {
                MatchCollection mc = writerPattern.Matches(name);
                writer = mc[0].ToString();
                name = name.Replace(writer, "");

            }
            //ppt파일 읽어와서 match되는것 찾기 참조 : http://mantascode.com/c-get-text-content-from-microsoft-powerpoint-file/
            name = name.Replace("  ", " ");
            name = name.Trim();
            //작성자 Parsing 끝


            //작성자삽입 시작
            //작성자가 있으면 그대로쓰고
            //없으면 작성자 삽입 textBox1을 작성자로
            if (button4.ForeColor == System.Drawing.Color.Black)
            {
                if (havingWriter3 == false && havingWriter2 == false && havingWriter1 == false)
                    writer = textBox1.Text;
            }
            //작성자삽입 끝


            //newName 새로운 파일명 취합
            string newName = String.Concat(date.ToString(), "_", name, "_", writer, "_", version);
            newName = newName.Replace("__", "_");
            try
            {
                //문자열 치환 시작
                if (button5.ForeColor == System.Drawing.Color.Black)    //문자열 치환
                {
                    if (checkBox2.Checked == false) //문자열 바꾸기
                        newName = newName.Replace(textBox3.Text, textBox4.Text);
                    else if (checkBox2.Checked == true)
                    {

                        Regex userPattern = new Regex(userRegex);
                        bool havingPattern = userPattern.IsMatch(newName);

                        if (havingPattern == true)
                        {
                            MatchCollection mc = userPattern.Matches(newName);
                            newName = newName.Replace(mc[0].ToString(), textBox4.Text);
                        }
                    }
                }
                //문자열 치환 끝
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.StackTrace);
            }

            //별표있으면 앞으로
            if (newName.Contains("★"))
            {
                newName = newName.Replace("★", "");
                newName = String.Concat("★", newName);
            }

            //기존
            string newNameIncludingExt = String.Concat(newName, ext);
            newNameIncludingExt = newNameIncludingExt.Replace("__", "_");
            
            //아래로 새로운것 3줄         
            new_name_List.Insert(index, newName);
            new_nameIncludingExt_List.Insert(index, newNameIncludingExt);
            AddListBox_ByCase();
        }

        void get_PathFileName(string dir)
        {

        }

        private static bool fileExistsCheck(string old_fileFullName)
        {
            if (System.IO.File.Exists(old_fileFullName))
                return true;
            else
                return false;
        }

        private static void Rename(string filePath, string old_fileFullName, string new_fileFullName)
        {
            string oldFile = filePath + "\\" + old_fileFullName;
            string newFile = filePath + "\\" + new_fileFullName;

            if (fileExistsCheck(oldFile))
            {
                System.IO.File.Move(oldFile, newFile);
                Console.WriteLine("FILE NAME CHANGE :: " + oldFile + " >> " + newFile);
            }
            else
                MessageBox.Show("파일이 존재하지 않습니다.");
        }

        private void menu1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1.Controls.Clear();
            //InitializeComponent();

        }

        private void menu2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel1.Controls.Clear();
            UserControl_ManualPage UC_manualPage = new UserControl_ManualPage();
            panel1.Controls.Add(UC_manualPage);
        }
        void AddListBox_ByCase()
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            //listBox3.Items.Clear();

            if (button6.ForeColor == System.Drawing.Color.Black) // 경로보기
            {
                //경로보기 , 확장자보기
                if (button8.ForeColor == System.Drawing.Color.Black)
                {

                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(file_List[i]);
                        listBox2.Items.Add(path_List[i] + "\\" + new_nameIncludingExt_List[i]);
                    }

                }
                //경로보기, 확장자 가림
                else if (button8.ForeColor == System.Drawing.Color.Gray)
                {
                    for (int i = 0; i < file_List.Count; i++)
                    {

                        listBox1.Items.Add(path_List[i] + "\\" + name_List[i]);
                        listBox2.Items.Add(path_List[i] + "\\" + new_name_List[i]);
                    }
                }
            }
            else if (button6.ForeColor == System.Drawing.Color.Gray)   //경로 가림
            {
                //경로가림, 확장자보기
                if (button8.ForeColor == System.Drawing.Color.Black)
                {

                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(fullName_List[i]);
                        listBox2.Items.Add(new_nameIncludingExt_List[i]);
                    }
                }
                //경로가림, 확장자가림
                else if (button8.ForeColor == System.Drawing.Color.Gray)
                {
                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(name_List[i]);
                        listBox2.Items.Add(new_name_List[i]);
                    }
                }
            }

        }
        //경로보기 버튼
        private void button6_Click(object sender, EventArgs e)
        {
            button6.ForeColor = System.Drawing.Color.Black;
            button7.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }

        //경로가림 버튼
        private void button7_Click(object sender, EventArgs e)
        {
            button7.ForeColor = System.Drawing.Color.Black;
            button6.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }

        //확장자보기 버튼
        private void button8_Click(object sender, EventArgs e)
        {
            button8.ForeColor = System.Drawing.Color.Black;
            button9.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }

        //확장자가림 버튼
        private void button9_Click(object sender, EventArgs e)
        {
            button9.ForeColor = System.Drawing.Color.Black;
            button8.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }

        //초기화 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();

            file_List.Clear();
            path_List.Clear();
            fullName_List.Clear();
            name_List.Clear();
            ext_List.Clear();
            new_name_List.Clear();
            new_nameIncludingExt_List.Clear();

            Initialization();
        }



        //파일불러오기
        private void button3_Click(object sender, EventArgs e)
        {
            List<String> files = new List<String>();
            openFileDialog1.InitialDirectory = "C:\\";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                
                foreach (String file in openFileDialog1.FileNames)
                {
                    if (file_List.Contains(file))
                    {
                        MessageBox.Show("중복된 파일을 불러왔습니다.");
                        return;
                    }
                    file_List.Add(file);

                    string path = file.Substring(0, file.LastIndexOf('\\'));
                    path_List.Add(path);

                    string fullName = file.Substring(file.LastIndexOf('\\') + 1);
                    fullName_List.Add(fullName);

                    string name = fullName.Substring(0, fullName.LastIndexOf('.'));
                    name_List.Add(name);

                    string ext = fullName.Substring(fullName.LastIndexOf('.'));
                    ext_List.Add(ext);

                    change_FileName(file);
                }

                String now = String.Format("{0:MM월d일 HH.mm.ss}", DateTime.Now);

                if (listBox3.Items.Count == 0)
                    listBox3.Items.Add(path_List[0] + "\\" + now);

                checkBox1.Visible = true;
                AddListBox_ByCase();
            }
        }

        //편집하기 버튼
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                button4.Visible = true;
                button5.Visible = true;
            }
            else if (checkBox1.Checked == false)
            {
                button4.Visible = false;
                button5.Visible = false;
                textBox1.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                label5.Visible = false;
                checkBox2.Visible = false;
                button4.ForeColor = System.Drawing.Color.Gray;
                button5.ForeColor = System.Drawing.Color.Gray;
            }
        }

        //Regex 사용 Check
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void textBox4_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        //작성자 삽입 버튼
        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.ForeColor == System.Drawing.Color.Gray)
            {
                button4.ForeColor = System.Drawing.Color.Black;
                textBox1.Visible = true;
            }
            else if (button4.ForeColor == System.Drawing.Color.Black)
            {
                button4.ForeColor = System.Drawing.Color.Gray;
                textBox1.Visible = false;
            }
        }

        //문자열 치환 버튼
        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.ForeColor == System.Drawing.Color.Gray)
            {
                button5.ForeColor = System.Drawing.Color.Black;
                textBox3.Visible = true;
                label5.Visible = true;
                textBox4.Visible = true;
                checkBox2.Visible = true;
            }
            else if (button5.ForeColor == System.Drawing.Color.Black)
            {
                button5.ForeColor = System.Drawing.Color.Gray;
                textBox3.Visible = false;
                label5.Visible = false;
                textBox4.Visible = false;
                checkBox2.Visible = false;
            }
        }

        //Naming Rule에 맞는 파일명들 녹색으로 표시
        private void listBox2_DrawItem(object sender, DrawItemEventArgs e)
        {

            if (listBox2.Items.Count == 0)
                return;
            if (listBox2.HorizontalExtent <= Width)
            {
                listBox2.HorizontalExtent = Width * 2;
                listBox2.HorizontalScrollbar = true;
            }

            Brush myBrush;
            string strText = listBox2.Items[e.Index].ToString();

            Regex writerPattern = new Regex(@"안건국|조현기|김규태|서대관|이형문|김용진|김수정|이나은|정일균|이준|명용환|정해비치|박상설|이태규");
            bool havingWriter = writerPattern.IsMatch(strText);
            if (havingWriter == true)
            {
                myBrush = Brushes.Green;
            }
            else
            {
                myBrush = Brushes.DarkGray;
            }

            e.Graphics.DrawString(listBox2.Items[e.Index].ToString(), e.Font, myBrush, e.Bounds, StringFormat.GenericDefault);



        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void 사용자수동변경도움말ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("프로그램 사용설명서를 참조해주세요.");

        }

        private void submenu1ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("프로그램 사용설명서를 참조해주세요.");
        }
    }
}
