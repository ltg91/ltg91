﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace NamingTool_v1
{
    public partial class UserControl_ManualPage : UserControl
    {
        List<String> file_List = new List<String>();    //전체경로+풀네임
        List<String> path_List = new List<String>();    //순수경로
        List<String> fullName_List = new List<String>();    //전체파일명(확장자포함)
        List<String> name_List = new List<String>();    //순수파일명(확장자 제외)
        List<String> ext_List = new List<String>();     //확장자 (ex) .ppt) 점까지 포함

        List<String> new_name_List = new List<String>();    //새로운 파일명(순수 파일명 확장자 제외)
        List<String> new_nameIncludingExt_List = new List<String>();    //새로운 파일명(확장자 포함)

        public UserControl_ManualPage()
        {
            InitializeComponent();
            //panel1 location : 0, 27

            this.AllowDrop = true; //드래그를 허용

            //드래그 관련 이벤트 연결
            this.DragOver += new DragEventHandler(Form1_DragOver);
            this.DragDrop += new DragEventHandler(Form1_DragDrop);

            dateTimePicker1.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            label3.Visible = false;
            button1.ForeColor = System.Drawing.Color.Gray;
            button3.ForeColor = System.Drawing.Color.Gray;
            button2.ForeColor = System.Drawing.Color.Gray;
            button4.ForeColor = System.Drawing.Color.Gray;

            button6.ForeColor = System.Drawing.Color.Gray;
            button7.ForeColor = System.Drawing.Color.Black;
            button8.ForeColor = System.Drawing.Color.Gray;
            button9.ForeColor = System.Drawing.Color.Black;

            //textBox1.KeyPress +=
            //  new KeyPressEventHandler(textBox1_KeyPress);
        }

        //드래그한 개체가 폼위로 올라갈때
        void Form1_DragOver(object sender, DragEventArgs e)
        {
            //드레그하는 개체가 파일이면
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                //마우스 커서를 Copy모양으로 바꿔준다.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                //아닐경우 커서의 모양을 θ 요런 모양으로 바꾼다.
                e.Effect = DragDropEffects.None;
            }

        }
        //드래그한 개체를 폼위에 올려 놓았을때
        void Form1_DragDrop(object sender, DragEventArgs e)
        {
            //객체들의 이름을 string 배열에 얻어온다.
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
            FileAttributes attr = File.GetAttributes(@"C:\Windows");    //폴더 확인을 위한 선언

            //중복 파일 체크 , 폴더 에러 처리
            if (null != files)
            {
                foreach (string filename in files)
                {
                    if (file_List.Contains(filename))
                    {
                        MessageBox.Show("중복된 파일을 불러왔습니다.");
                        return;
                    }
                    attr = File.GetAttributes(filename);
                    if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                    {
                        MessageBox.Show("폴더 형태는 불러 올 수 없습니다.");
                        return;
                    }
                }
            }

            //경로제외&확장자제외
            if (files != null)
            {
                foreach (string file in files)
                {
                    file_List.Add(file);

                    string path = file.Substring(0, file.LastIndexOf('\\'));
                    path_List.Add(path);

                    string fullName = file.Substring(file.LastIndexOf('\\') + 1);
                    fullName_List.Add(fullName);

                    string name = fullName.Substring(0, fullName.LastIndexOf('.'));
                    name_List.Add(name);

                    change_FileName(file);
                }
            }

            AddListBox_ByCase();

            String now = String.Format("{0:MM월d일 HH.mm.ss}", DateTime.Now);
            now = String.Concat("백업파일_", now);
            if (listBox3.Items.Count == 0)
                listBox3.Items.Add(path_List[0] + "\\" + now);
        }
        /*
        void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar>=48 || e.KeyChar <=46 )
                foreach(string file in file_List)
                    change_FileName(file);
        }
        
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Determine whether the key entered is the F1 key. Display help if it is.
            if (e.KeyChar>=48 || e.KeyChar <=46 )
            {
                
                foreach (string file in file_List)
                    change_FileName(file);
            }
        }
        */

        //ListBox에 item 추가
        void AddListBox_ByCase()
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            //listBox3.Items.Clear();

            if (button6.ForeColor == System.Drawing.Color.Black) // 경로보기
            {
                //경로보기 , 확장자보기
                if (button8.ForeColor == System.Drawing.Color.Black)
                {

                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(file_List[i]);
                        listBox2.Items.Add(path_List[i] + "\\" + new_nameIncludingExt_List[i]);
                    }

                }
                //경로보기, 확장자 가림
                else if (button8.ForeColor == System.Drawing.Color.Gray)
                {
                    for (int i = 0; i < file_List.Count; i++)
                    {

                        listBox1.Items.Add(path_List[i] + "\\" + name_List[i]);
                        listBox2.Items.Add(path_List[i] + "\\" + new_name_List[i]);
                    }
                }
            }
            else if (button6.ForeColor == System.Drawing.Color.Gray)   //경로 가림
            {
                //경로가림, 확장자보기
                if (button8.ForeColor == System.Drawing.Color.Black)
                {

                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(fullName_List[i]);
                        listBox2.Items.Add(new_nameIncludingExt_List[i]);
                    }
                }
                //경로가림, 확장자가림
                else if (button8.ForeColor == System.Drawing.Color.Gray)
                {
                    for (int i = 0; i < file_List.Count; i++)
                    {
                        listBox1.Items.Add(name_List[i]);
                        listBox2.Items.Add(new_name_List[i]);
                    }
                }
            }

        }

        //초기화 버튼
        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            file_List.Clear();
            path_List.Clear();
            fullName_List.Clear();
            name_List.Clear();
            ext_List.Clear();
            new_name_List.Clear();
            new_nameIncludingExt_List.Clear();

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            checkBox2.Checked = false;

            button4.ForeColor = System.Drawing.Color.Gray;
            button1.ForeColor = System.Drawing.Color.Gray;
            button2.ForeColor = System.Drawing.Color.Gray;
            button3.ForeColor = System.Drawing.Color.Gray;

            dateTimePicker1.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            label3.Visible = false;
            checkBox2.Visible = false;


        }

        //변환 버튼
        private void button5_Click(object sender, EventArgs e)
        {


            //기존파일 Temp 저장
            String now = listBox3.Items[0].ToString();

            if (System.IO.Directory.Exists(now))
            {
                MessageBox.Show("이미 변경 버튼을 한 번 눌렀습니다. \n초기화 후 다시 진행해주세요.");
                return;
            }

            //기존파일 저장
            DirectoryInfo di = new DirectoryInfo(now);
            if (di.Exists == false)
            {
                di.Create();
            }


            //백업하기 (백업하기 체크 되있으면)
            if (checkBox1.Checked == true)
            {
                for (int i = 0; i < file_List.Count; i++)
                {
                    string oldFile = path_List[i] + "\\" + fullName_List[i];
                    string newFile = now + "\\" + fullName_List[i];

                    System.IO.File.Copy(oldFile, newFile);
                }
            }

            //파일명 변경
            for (int i = 0; i < file_List.Count; i++)
            {
                Rename(path_List[i], fullName_List[i], new_nameIncludingExt_List[i]);
            }


            //모든 것 클리어
            //path_List.Clear();
            //name_List.Clear();
            //fullName_List.Clear();
            ext_List.Clear();

            MessageBox.Show("변환 성공했습니다.");
        }
        int searchNowIndex(String file)
        {
            for (int i = 0; i < file_List.Count; i++)
            {
                if (file_List[i].ToString().Contains(file))
                {
                    //MessageBox.Show(i.ToString());

                    return i;
                }
            }

            return 0;
        }
        //파일명 변경
        void change_FileName(String file)
        {

            //지금 돌아가는 Index만 new_name_List, new_nameIncludingExt_List ~~ Delete!
            //new_name_List.Clear();
            //new_name_List[searchNowIndex(file)] = "";
            //new_nameIncludingExt_List[searchNowIndex(file)] = "";
            //new_nameIncludingExt_List.Clear();
            int index = searchNowIndex(file);

            string date = "";
            string writer = "";
            string version = "";
            string userRegex = textBox3.Text;

            string path = file.Substring(0, file.LastIndexOf('\\'));

            //순수경로명
            //path_List.Add(path);

            string fullName = file.Substring(file.LastIndexOf('\\') + 1);
            //순수 파일명 (확장자 포함)
            //fullName_List.Add(fullName);

            string name = fullName.Substring(0, fullName.LastIndexOf('.'));
            //순수 파일명(확장자 제외)
            //name_List.Add(name);

            string ext = fullName.Substring(fullName.LastIndexOf('.'));
            //ext_List.Add(ext);

            if (button1.ForeColor == System.Drawing.Color.Black)    //날짜
            {
                date = dateTimePicker1.Value.ToString("yyMMdd") + "_";
            }


            if (button2.ForeColor == System.Drawing.Color.Black)    //버전
            {
                version = "_" + textBox2.Text;
            }

            //원래 문자열치환 위치

            string newNameIncludingExt = String.Concat(date, name, version, ext);
            if (button3.ForeColor == System.Drawing.Color.Black)    //작성자
            {
                writer = textBox1.Text;
                Regex versionPattern = new Regex(@"([v|V]+)([0-9]+).([0-9]+)");
                Regex version1Pattern = new Regex(@"([v|V]+)([0-9]+)");
                Regex version2Pattern = new Regex(@"([v|V]+)([f|F]+)");
                bool havingVersion = versionPattern.IsMatch(name);
                bool havingVersion1 = version1Pattern.IsMatch(name);
                bool havingVersion2 = version2Pattern.IsMatch(name);

                if (havingVersion == true)
                {
                    newNameIncludingExt = newNameIncludingExt.Replace("_v", "_" + writer + "_v");
                    newNameIncludingExt = newNameIncludingExt.Replace("_V", "_" + writer + "_v");
                }
                else if (havingVersion1 == true)
                {
                    newNameIncludingExt = newNameIncludingExt.Replace("_v", "_" + writer + "_v");
                    newNameIncludingExt = newNameIncludingExt.Replace("_V", "_" + writer + "_v");
                }
                else if (havingVersion2 == true)
                {
                    newNameIncludingExt = newNameIncludingExt.Replace("_v", "_" + writer + "_v");
                    newNameIncludingExt = newNameIncludingExt.Replace("_V", "_" + writer + "_v");
                }
                else
                {
                    newNameIncludingExt = String.Concat(date, name, "_", writer, version, ext);

                }
                /*
                if (newNameIncludingExt.Contains("_v1") || name.Contains("_v2") || name.Contains("_v3") || name.Contains("_v4") || name.Contains("_v5") || name.Contains("_v6") || name.Contains("_v7")
                    || name.Contains("_v8") || name.Contains("_v9") || name.Contains("_vF") || newNameIncludingExt.Contains("_V1") || name.Contains("_V2") || name.Contains("_V3") || name.Contains("_V4") 
                    || name.Contains("_V5") || name.Contains("_V6") || name.Contains("_V7")
                    || name.Contains("_V8") || name.Contains("_V9") || name.Contains("_VF"))
                {
                    newNameIncludingExt = newNameIncludingExt.Replace("_v", "_" + writer + "_v");
                    newNameIncludingExt = newNameIncludingExt.Replace("_V", "_" + writer + "_v");
                }*/

            }
            //문자열 바꾸기
            try
            {
                String newNameExcludingExt = newNameIncludingExt.Substring(0, newNameIncludingExt.LastIndexOf('.'));
                if (button4.ForeColor == System.Drawing.Color.Black)    //문자열 치환
                {
                    //textBox3.Text = "";
                    //textBox4.Text = "";

                    if (checkBox2.Checked == false) //문자열 바꾸기
                        newNameExcludingExt = newNameExcludingExt.Replace(textBox3.Text, textBox4.Text);
                    else if (checkBox2.Checked == true)
                    {

                        Regex userPattern = new Regex(userRegex);
                        bool havingPattern = userPattern.IsMatch(newNameExcludingExt);

                        if (havingPattern == true)
                        {
                            MatchCollection mc = userPattern.Matches(newNameExcludingExt);

                            newNameExcludingExt = newNameExcludingExt.Replace(mc[0].ToString(), textBox4.Text);
                        }
                    }
                }
                //별표있으면 앞으로
                if (newNameExcludingExt.Contains("★"))
                {
                    newNameExcludingExt = newNameExcludingExt.Replace("★", "");
                    newNameExcludingExt = String.Concat("★", newNameExcludingExt);
                }
                newNameIncludingExt = String.Concat(newNameExcludingExt, ext);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.StackTrace);
            }

            //Rename(path, fullName, newNameIncludingExt);

            //new_name, new_nameIncludingExt_List 추가
            //new_nameIncludingExt_List.Add(newNameIncludingExt);


            string newName = newNameIncludingExt.Substring(0, newNameIncludingExt.LastIndexOf('.'));

            new_nameIncludingExt_List.Insert(index, newNameIncludingExt);
            //new_nameIncludingExt_List.RemoveAt(index);
            //new_nameIncludingExt_List[searchNowIndex(file)] = newNameIncludingExt;
            //보기에 체크되있는 데로 완성 파일 listBox2에 추가
            //new_name_List[searchNowIndex(file)] = newName;
            //new_name_List.Add(newName);
            new_name_List.Insert(index, newName);
            //new_name_List.RemoveAt(index);

            AddListBox_ByCase();
        }
        private static bool fileExistsCheck(string old_fileFullName)
        {
            if (System.IO.File.Exists(old_fileFullName))
                return true;
            else
                return false;
        }
        private static void Rename(string filePath, string old_fileFullName, string new_fileFullName)
        {
            string oldFile = filePath + "\\" + old_fileFullName;
            string newFile = filePath + "\\" + new_fileFullName;

            if (fileExistsCheck(oldFile))
            {
                System.IO.File.Move(oldFile, newFile);
                Console.WriteLine("FILE NAME CHANGE :: " + oldFile + " >> " + newFile);
            }
            else
                MessageBox.Show("파일이 존재하지 않습니다.");
        }
        private void initializeDateTimePicker()
        {
            dateTimePicker1.CustomFormat = "yyMMdd";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt1 = dateTimePicker1.Value;
            string dt = dt1.ToString("yyMMdd");
        }

        //날짜 삽입 버튼
        private void button1_Click(object sender, EventArgs e)
        {

            if (button1.ForeColor == System.Drawing.Color.Gray)
            {
                button1.ForeColor = System.Drawing.Color.Black;
                dateTimePicker1.Visible = true;
            }
            else if (button1.ForeColor == System.Drawing.Color.Black)
            {
                button1.ForeColor = System.Drawing.Color.Gray;
                dateTimePicker1.Visible = false;
            }


        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {

        }

        //작성자 삽입
        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.ForeColor == System.Drawing.Color.Gray)
            {
                button3.ForeColor = System.Drawing.Color.Black;
                textBox1.Visible = true;
            }
            else if (button3.ForeColor == System.Drawing.Color.Black)
            {
                button3.ForeColor = System.Drawing.Color.Gray;
                textBox1.Visible = false;
            }
        }

        //뒤에 버전 삽입

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.ForeColor == System.Drawing.Color.Gray)
            {
                button2.ForeColor = System.Drawing.Color.Black;
                textBox2.Text = "v";
                textBox2.Visible = true;
            }
            else if (button2.ForeColor == System.Drawing.Color.Black)
            {
                button2.ForeColor = System.Drawing.Color.Gray;
                textBox2.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        //경로보기 btn
        private void button6_Click(object sender, EventArgs e)
        {
            button6.ForeColor = System.Drawing.Color.Black;
            button7.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }
        //경로가림 btn
        private void button7_Click(object sender, EventArgs e)
        {
            button7.ForeColor = System.Drawing.Color.Black;
            button6.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }
        //확장자보기 btn
        private void button8_Click(object sender, EventArgs e)
        {
            button8.ForeColor = System.Drawing.Color.Black;
            button9.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }
        //확장자가림 btn
        private void button9_Click(object sender, EventArgs e)
        {
            button9.ForeColor = System.Drawing.Color.Black;
            button8.ForeColor = System.Drawing.Color.Gray;
            AddListBox_ByCase();
        }

        //문자열치환 btn
        private void button4_Click_1(object sender, EventArgs e)
        {
            if (button4.ForeColor == System.Drawing.Color.Gray)
            {
                button4.ForeColor = System.Drawing.Color.Black;
                textBox3.Visible = true;
                label3.Visible = true;
                textBox4.Visible = true;
                checkBox2.Visible = true;
            }
            else if (button4.ForeColor == System.Drawing.Color.Black)
            {
                button4.ForeColor = System.Drawing.Color.Gray;
                textBox3.Visible = false;
                label3.Visible = false;
                textBox4.Visible = false;
                checkBox2.Visible = false;
            }
        }

        private void button11_Click(object sender, EventArgs e) //파일불러오기
        {
            List<String> files = new List<String>();
            openFileDialog1.InitialDirectory = "C:\\";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                foreach (String file in openFileDialog1.FileNames)
                {
                    if (file_List.Contains(file))
                    {
                        MessageBox.Show("중복된 파일을 불러왔습니다.");
                        return;
                    }
                    file_List.Add(file);

                    string path = file.Substring(0, file.LastIndexOf('\\'));
                    path_List.Add(path);

                    string fullName = file.Substring(file.LastIndexOf('\\') + 1);
                    fullName_List.Add(fullName);

                    string name = fullName.Substring(0, fullName.LastIndexOf('.'));
                    name_List.Add(name);

                    string ext = fullName.Substring(fullName.LastIndexOf('.'));
                    ext_List.Add(ext);

                    change_FileName(file);
                }

                String now = String.Format("{0:MM월d일 HH.mm.ss}", DateTime.Now);
                now = String.Concat("백업파일_", now);
                if (listBox3.Items.Count == 0)
                    listBox3.Items.Add(path_List[0] + "\\" + now);

                AddListBox_ByCase();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar >= 48 || e.KeyChar <= 47)
            {
                foreach (string file in file_List)
                    change_FileName(file);
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //foreach (string file in file_List)
            // change_FileName(file);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*
            if (e.KeyChar >= 48 || e.KeyChar <= 47)
            {
                foreach (string file in file_List)
                    change_FileName(file);
            }*/
        }

        private void dateTimePicker1_MouseDown(object sender, MouseEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void dateTimePicker1_CloseUp(object sender, EventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            //foreach (string file in file_List)
            //    change_FileName(file);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void textBox4_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            foreach (string file in file_List)
                change_FileName(file);
        }

        private void listBox2_DrawItem(object sender, DrawItemEventArgs e)
        {

            if (listBox2.Items.Count == 0)
                return;

            if (listBox2.HorizontalExtent <= Width)
            {
                listBox2.HorizontalExtent = Width * 2;
                listBox2.HorizontalScrollbar = true;
            }

            Brush myBrush;
            string strText = listBox2.Items[e.Index].ToString();
            Regex date6Pattern = new Regex(@"[0-1]+[0-9]+[0-1]+[0-9]+[0-3]+[0-9]");
            Regex writerPattern = new Regex(@"안건국GJ|조현기GJ|김규태GJ|서대관GJ|이형문GJ|김용진GJ|김수정DR|이나은DR|정일균DR|이준DR|명용환DR|정해비치SW|박상설SW|이태규SW");

            bool havingWriter = writerPattern.IsMatch(strText);
            bool having6Date = date6Pattern.IsMatch(strText);

            Regex versionPattern = new Regex(@"([v|V]+)([0-9]+).([0-9]+)");  //Regex versionPattern = new Regex(@"([v|V]+)([0-9]+)");
            Regex version1Pattern = new Regex(@"([v|V]+)([0-9]+)");
            Regex version2Pattern = new Regex(@"([v|V]+)([f|F]+)");
            bool havingVersion = versionPattern.IsMatch(strText);
            bool havingVersion1 = version1Pattern.IsMatch(strText);
            bool havingVersion2 = version2Pattern.IsMatch(strText);

            if (havingVersion == true || havingVersion1 == true || havingVersion2 == true)
            {
                if (having6Date == true && havingWriter == true)
                {
                    myBrush = Brushes.Green;
                }
                else
                {
                    myBrush = Brushes.DarkGray;
                }
            }
            else
            {
                myBrush = Brushes.DarkGray;
            }
            listBox2.HorizontalScrollbar = true;
            e.Graphics.DrawString(listBox2.Items[e.Index].ToString(), e.Font, myBrush, e.Bounds, StringFormat.GenericDefault);

            e.DrawFocusRectangle();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

    }
}
